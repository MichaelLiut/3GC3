//
//  Asteroid.cpp
//  Asteroids
//
//  Created by Brandon Da Silva on 12/20/2013.
//  Copyright (c) 2013 Brandon Da Silva. All rights reserved.
//

#include "Asteroid.h"

Asteroid::Asteroid(){}